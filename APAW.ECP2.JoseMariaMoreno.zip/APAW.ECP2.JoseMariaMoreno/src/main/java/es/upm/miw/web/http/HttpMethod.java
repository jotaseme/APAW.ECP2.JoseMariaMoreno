package es.upm.miw.web.http;

public enum HttpMethod {
    GET, POST, PUT, DELETE, OPTIONS, HEAD
}
