package es.upm.miw.apiArchitectureSport.daos;

import es.upm.miw.apiArchitectureTheme.entities.Sport;

public interface SportDao extends GenericDao<Sport, String> {
}
